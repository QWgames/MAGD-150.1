let song = ["Tamagotchi", "Taking What's Not Yours", "Outlaws Get No Entry", "Sleepwalk", "southbound"];
let artist = ["TIMMS", "TV Girl", "Taku Iwasaki", "Forrest Day", "Artemas"];
let songAndArtist = ["Tamagotchi - TIMMS", "Taking What's Not Yours - TV Girl", "Outlaws Get No Entry - Taku Iwasaki", "Sleepwalk - Forrest Day", "southbound - Artemas"];

function setup() {
  createCanvas(700, 400);
  background(255, 220, 183);
  song.push("Bathed In Sound");
  artist.push("Cosmo Sheldrake");
  songAndArtist.push("Bathed In Sound - Cosmo Sheldrake");
  song.unshift("CANDLEBURN");
  artist.unshift("Rabbitology");
  songAndArtist.unshift("CANDLEBURN - Rabbitology");
  console.log(songAndArtist);
  fill(232, 58, 96);
  // :)
  text("Array 1: "+song,10,100);
  text("Array 2: "+artist,10,150);
  //for (let p = 0; p<7; p++){
    let num = Math.floor(random(0,song.length));
    console.log(num);
   // text("Array 1: "+song,10,100);
   // text("Array 2: "+artist,10,150);
  text("Made by Quinn :)",600,390);
  textSize(20);
  text("Random 1: "+song[num],10,200);
    // if I used [num,1], there will only be one option, but it won't be random.
  text("Random 2: "+artist[num],10,250);
    // if I use [num], all options appear on top of each other, and it still doesn't appear to be random.
    // using something like [random.floor] just results in an error.
  text("Random 1 & 2: "+songAndArtist[num],10,300);
    // How do I get it to give me just one --actually random -- string?
  //}
  
}