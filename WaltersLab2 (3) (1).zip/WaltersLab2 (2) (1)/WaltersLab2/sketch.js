function setup() {
  createCanvas(400, 400);
  frameRate(35);
  colorMode (RGB);
  background(255, 216, 220);
}

function draw() {
  colorMode (RGB);
  let mx = mouseX;
  let my = mouseY;
  let px = pmouseX;
  let py = pmouseY;
  fill(255,178,0)
  stroke(255,157,132);
  circle(px,py,40);
  let base = 3;
  let d = pow(base, 1);
  circle(10, 10, d);
  d = pow(base, 2);
  circle(20, 20, d);
  d = pow(base, 3);
  circle(40, 40, d);
  let f = sqrt(16);
  circle(60, 60, f);
  f = sqrt(1600);
  circle(80, 80, f);

}